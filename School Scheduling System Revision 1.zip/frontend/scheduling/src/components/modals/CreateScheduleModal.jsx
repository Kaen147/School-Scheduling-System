import Swal from "sweetalert2";

const getYearSuffix = (year) => {
  switch (year) {
    case "1":
      return "st";
    case "2":
      return "nd";
    case "3":
      return "rd";
    default:
      return "th";
  }
};

export const showCreateScheduleModal = async (courses, navigate) => {
  const { value: formValues } = await Swal.fire({
    title: "Create New Schedule",
    html: `
      <form style="text-align: left; display: flex; flex-direction: column; gap: 12px;">
        <div>
          <label for="schedule-course" style="display: block; font-size: 13px; margin-bottom: 5px; font-weight: 600; color: #1F2937;">Course <span style="color: #EF4444;">*</span></label>
          <select id="schedule-course" style="width: 100%; padding: 8px 10px; font-size: 13px; border: 1px solid #D1D5DB; border-radius: 6px; background-color: #FFFFFF; cursor: pointer; outline: none;">
            <option value="">— Select a course —</option>
            ${courses
              .map((c) => `<option value="${c._id}">${c.abbreviation ? c.abbreviation + ' - ' : ''}${c.name}</option>`)
              .join("")}
          </select>
        </div>
        
        <div>
          <label for="schedule-year" style="display: block; font-size: 13px; margin-bottom: 5px; font-weight: 600; color: #1F2937;">Year Level <span style="color: #EF4444;">*</span></label>
          <select id="schedule-year" style="width: 100%; padding: 8px 10px; font-size: 13px; border: 1px solid #D1D5DB; border-radius: 6px; background-color: #FFFFFF; cursor: pointer; outline: none;">
            <option value="">— Select year level —</option>
            <option value="1">1st Year</option>
            <option value="2">2nd Year</option>
            <option value="3">3rd Year</option>
            <option value="4">4th Year</option>
          </select>
        </div>
        
        <div>
          <label for="schedule-semester" style="display: block; font-size: 13px; margin-bottom: 5px; font-weight: 600; color: #1F2937;">Semester <span style="color: #EF4444;">*</span></label>
          <select id="schedule-semester" style="width: 100%; padding: 8px 10px; font-size: 13px; border: 1px solid #D1D5DB; border-radius: 6px; background-color: #FFFFFF; cursor: pointer; outline: none;">
            <option value="">— Select semester —</option>
            <option value="1">1st Semester</option>
            <option value="2">2nd Semester</option>
            <option value="summer">Summer</option>
          </select>
        </div>
      </form>
    `,
    width: "420px",
    padding: "0",
    customClass: {
      popup: 'create-schedule-popup',
      container: 'create-schedule-container',
      actions: 'create-schedule-actions',
    },
    allowOutsideClick: false,
    allowEscapeKey: true,
    focusConfirm: false,
    showCancelButton: true,
    confirmButtonText: "Create Schedule",
    cancelButtonText: "Cancel",
    confirmButtonColor: "#3B82F6",
    cancelButtonColor: "#6B7280",
    didOpen: () => {
      const popup = document.querySelector('.create-schedule-popup');
      if (popup) {
        popup.style.overflow = 'visible';
        popup.style.overflowY = 'visible';
        popup.style.maxHeight = 'none';
      }
      const header = document.querySelector('.swal2-html-container');
      if (header) {
        header.style.padding = '20px 20px 15px 20px';
      }
      
      // Style buttons
      const confirmBtn = document.querySelector('.swal2-confirm');
      const cancelBtn = document.querySelector('.swal2-cancel');
      
      if (confirmBtn) {
        confirmBtn.style.backgroundColor = '#3B82F6';
        confirmBtn.style.color = 'white';
        confirmBtn.style.border = 'none';
        confirmBtn.style.borderRadius = '6px';
        confirmBtn.style.padding = '10px 20px';
        confirmBtn.style.fontSize = '14px';
        confirmBtn.style.fontWeight = '600';
        confirmBtn.style.cursor = 'pointer';
        confirmBtn.style.marginRight = '10px';
      }
      
      if (cancelBtn) {
        cancelBtn.style.backgroundColor = '#6B7280';
        cancelBtn.style.color = 'white';
        cancelBtn.style.border = 'none';
        cancelBtn.style.borderRadius = '6px';
        cancelBtn.style.padding = '10px 20px';
        cancelBtn.style.fontSize = '14px';
        cancelBtn.style.fontWeight = '600';
        cancelBtn.style.cursor = 'pointer';
      }
      
      const actions = document.querySelector('.swal2-actions');
      if (actions) {
        actions.style.padding = '20px 20px';
        actions.style.gap = '10px';
      }
    },
    preConfirm: () => {
      const courseId = document.getElementById("schedule-course").value;
      const yearLevel = document.getElementById("schedule-year").value;
      const semester = document.getElementById("schedule-semester").value;
      if (!courseId || !yearLevel || !semester) {
        Swal.showValidationMessage("Please select all fields");
        return false;
      }
      return { courseId, yearLevel, semester };
    },
  });

  if (formValues) {
    const selectedCourse = courses.find((c) => c._id === formValues.courseId);
    const scheduleInfo = {
      courseId: formValues.courseId,
      courseName: selectedCourse?.name || "",
      courseAbbreviation: selectedCourse?.abbreviation || "",
      yearLevel: formValues.yearLevel,
      semester: formValues.semester,
    };

    localStorage.setItem("scheduleInfo", JSON.stringify(scheduleInfo));

    Swal.fire({
      icon: "success",
      title: "Schedule Created!",
      text: `Creating schedule for ${selectedCourse?.name} - ${
        formValues.yearLevel
      }${getYearSuffix(formValues.yearLevel)} Year`,
      timer: 2000,
      showConfirmButton: false,
    }).then(() => navigate("/timetable"));
  }
};

export default showCreateScheduleModal;
